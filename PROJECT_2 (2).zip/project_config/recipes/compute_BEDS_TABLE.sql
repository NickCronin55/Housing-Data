SELECT DISTINCT BED
  FROM "PROJECT_2_clean_realtor_table_no_puerto_rico"
  WHERE BED < 7;