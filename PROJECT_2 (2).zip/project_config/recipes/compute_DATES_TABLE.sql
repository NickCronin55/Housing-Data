Select distinct substring(sold_date, 0,11) SOLD_DATE
from "PROJECT_2_clean_realtor_table_no_puerto_rico";