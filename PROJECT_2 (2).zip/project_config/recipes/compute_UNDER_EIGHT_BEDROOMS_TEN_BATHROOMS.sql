SELECT *
  FROM "PROJECT_2_under_eight_bedrooms"
  
  WHERE
    STATE != 'Georgia'
    AND BATH < 11
    