SELECT *
  FROM "PROJECT_2_distinct_base_new_date_month_year_distinct"

WHERE
    STATE != 'Puerto Rico'
    AND BED < 8
    AND STATE != 'Virgin Islands';