SELECT
    *
FROM
    "PROJECT_2_realtor_data_table"
WHERE
    STATE != 'Puerto Rico'
    AND BED is not null
    AND BATH is not null
    AND SOLD_DATE is not null
    AND SOLD_DATE > '2010-01-01';
