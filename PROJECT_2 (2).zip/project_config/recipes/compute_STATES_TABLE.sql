SELECT DISTINCT STATE
  FROM "PROJECT_2_clean_realtor_table_no_puerto_rico"
  ORDER BY STATE;